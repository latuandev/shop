<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Shipped extends Model
{
    //
}
